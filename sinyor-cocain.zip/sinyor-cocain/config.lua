Config={}

Config.Kokaintoplama = { 
        vector3(5371.1, -5238.02, 32.83),
        vector3(5378.13, -5243.61, 33.44),
        vector3(5382.4, -5246.25, 33.72),
        vector3(5378.44, -5247.39, 33.57),
        vector3(5363.74, -5236.67, 32.65),
        vector3(5362.67, -5227.32, 31.93),
        vector3(5370.17, -5233.44, 32.66),
        vector3(5376.55, -5238.53, 33.22),
        vector3(5388.82, -5247.62, 34.18)
}

Config.Kokainisleme = vector3(5067.35, -4591.4, 2.86)
Config.Kokainisleme2 = vector3(2329.37, 2571.34, 46.72)
Config.markerboyutu = 1.0 
Config.KokainislemeMiktar = 5 
Config.KokainislemeMiktar2 = 5 
Config.KokainMin = 1 
Config.KokainMax = 2 