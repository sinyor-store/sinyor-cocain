fx_version "adamant"

game "gta5"

client_script{"client.lua"}
 
server_scripts{"server.lua"}

shared_scripts { 
	'config.lua'
}server_scripts { '@mysql-async/lib/MySQL.lua' }