local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent("scocatoplama")
AddEventHandler("scocatoplama", function()
    local xPlayer = QBCore.Functions.GetPlayer(source)
    xPlayer.Functions.AddItem("coke", math.random(Config.KokainMin,Config.KokainMax))
end)

RegisterNetEvent("scocaisle")
AddEventHandler("scocaisle", function()
    local xPlayer = QBCore.Functions.GetPlayer(source)
    local item = math.random(1,100)
    if xPlayer.Functions.RemoveItem("coke", Config.KokainislemeMiktar) then
            xPlayer.Functions.AddItem("coca_leaf", 1)
        TriggerClientEvent('QBCore:Notify', source, { type = 'success', text = 'Kokain İşledin!', length = 2500})
    else
        TriggerClientEvent('QBCore:Notify', source, { type = 'error', text = 'Yeterince Kokainin Yok!', length = 2500})
    end
end)


RegisterNetEvent("scocaisle2")
AddEventHandler("scocaisle2", function()
    local xPlayer = QBCore.Functions.GetPlayer(source)
    local item = math.random(1,100)
    if xPlayer.Functions.RemoveItem("afyon", Config.KokainislemeMiktar2) then
            xPlayer.Functions.AddItem("afyonislenmis", 1)
        TriggerClientEvent('QBCore:Notify', source, { type = 'success', text = 'Afyon İşledin!', length = 2500})
    else
        TriggerClientEvent('QBCore:Notify', source, { type = 'error', text = 'Yeterince Afyon Yok!', length = 2500})
    end
end)



