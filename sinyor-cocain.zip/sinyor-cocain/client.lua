slocal availableActions = {}
local cord = Config.Kokaintoplama
-- Kokain toplama

local sonkokain = 1


CreateThread(function()
    while true do
        local sleep = 1000
        local player = PlayerPedId()
        local playercoords = GetEntityCoords(player)
        local dst = GetDistanceBetweenCoords(playercoords, Config.Kokaintoplama[sonkokain].x, Config.Kokaintoplama[sonkokain].y, Config.Kokaintoplama[sonkokain].z, true)
        local dst2 = GetDistanceBetweenCoords(playercoords, Config.Kokaintoplama[sonkokain].x, Config.Kokaintoplama[sonkokain].y, Config.Kokaintoplama[sonkokain].z, true)
        if dst2 < 50 then
            sleep = 2
           DrawMarker(2,Config.Kokaintoplama[sonkokain].x, Config.Kokaintoplama[sonkokain].y, Config.Kokaintoplama[sonkokain].z,0.0, 0.0, 0.0, 0.0, 0, 0.0, Config.markerboyutu, Config.markerboyutu, Config.markerboyutu,  100, 0, 254, 150, 0, 0, 0, 0, 0, 0, 0, false, true, 2, nil, nil, false)
        --    DrawMarker(2, Config.Kokaintoplama[sonkokain].x, Config.Kokaintoplama[sonkokain].y, Config.Kokaintoplama[sonkokain].z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 100, 0, 254, 150, 0, 0, 0, 0, 0, 0, 0)
        --    DrawText3Ds(Config.Kokaintoplama[sonkokain].x, Config.Kokaintoplama[sonkokain].y, Config.Kokaintoplama[sonkokain].z + 0.1, '[E] Kokain Topla')
       if dst2 < 5 then 
        DrawText3Ds(Config.Kokaintoplama[sonkokain].x, Config.Kokaintoplama[sonkokain].y, Config.Kokaintoplama[sonkokain].z + 0.1, '[E] Kokain Topla')
         
       end
            if dst2 < 1 then
                if IsControlJustReleased(0, 38) then
                    sonkokain = math.random(1, #Config.Kokaintoplama)
                    kokaintopla()
                end
            end
        end
        Wait(sleep)
    end
end)


function kokaintopla()
    if not topluyormu then
        topluyormu = true
        exports['progressbar']:Progress({
            name = "kokaintopla",
            duration = 2000,
            label = 'Kokain topluyorsun...',
            useWhileDead = false,
            canCancel = false,
            controlDisables = {
                disableMovement = true,
                disableCarMovement = true,
                disableMouse = false,
                disableCombat = true,
            },
            animation = {
                animDict = "mp_arresting",
                anim = "a_uncuff",
                flags = 49,
            },
        }, function(cancelled)
            if not cancelled then
                TriggerServerEvent('scocatoplama')
                topluyormu = false
            else
            end
        end)
    end
end

--isleme

local cord = Config.Kokainisleme

CreateThread(function()
    local sleep = 2000
    while true do
        local player = PlayerPedId()
        local playercoords = GetEntityCoords(player)
        local distance = GetDistanceBetweenCoords(playercoords, cord.x, cord.y, cord.z, true)
        if distance < 20 then
            sleep = 0
            DrawMarker(2,cord.x, cord.y, cord.z,0.0, 0.0, 0.0, 0.0, 0, 0.0, Config.markerboyutu, Config.markerboyutu, Config.markerboyutu, 255, 0, 0, 150, false, false, 2, nil, nil, false)
            if distance < 20 then
                DrawText3D(cord.x,cord.y,cord.z, '[E] Kokainlerini İşle')
                if IsControlJustReleased(0, 38) then
                    exports['ps-ui']:Circle(function(success)
                        if success then
                            TriggerServerEvent("scocaisle")
                        end
                    end)
                end
            else
                sleep = 1000
            end
        end
        Wait(sleep)
    end
end)


--- isleme 2

local cord = Config.Kokainisleme2

CreateThread(function()
    local sleep = 2000
    while true do
        local player = PlayerPedId()
        local playercoords = GetEntityCoords(player)
        local distance = GetDistanceBetweenCoords(playercoords, cord.x, cord.y, cord.z, true)
        if distance < 20 then
            sleep = 0
            DrawMarker(2,cord.x, cord.y, cord.z,0.0, 0.0, 0.0, 0.0, 0, 0.0, Config.markerboyutu, Config.markerboyutu, Config.markerboyutu, 255, 0, 0, 150, false, false, 2, nil, nil, false)
            if distance < 20 then
                DrawText3D(cord.x,cord.y,cord.z, '[E] Afyonlarını İşle')
                if IsControlJustReleased(0, 38) then
                    exports['ps-ui']:Circle(function(success)
                        if success then
                            TriggerServerEvent("scocaisle2")
                        end
                    end)
                end
            else
                sleep = 1000
            end
        end
        Wait(sleep)
    end
end)

-- Satış



function DrawText3D(x,y,z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    SetTextScale(0.30, 0.30)
    SetTextFont(0)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 250
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 0, 0, 0, 75)
end

function DrawText3Ds(x,y,z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    SetTextScale(0.30, 0.30)
    SetTextFont(0)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 250
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 0, 0, 0, 75)
end
